﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Classical_Music_Library.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
