using System;

namespace Classical_Music_Library
{
    public class Album
    {
        public string TitleName { get; set; }
        public string AlbumName { get; set; }
        public string ComposerName { get; set; }
        public DateTime ReleasedDate { get; set; }
        public string ArtistName { get; set; }
    }
}
