﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Classical_Music_Library.Entities;

namespace Classical_Music_Library.Controllers
{
    [ApiController]
    [Route("Music")]
    public class MusicController : ControllerBase
    {
        private static readonly string[] ComposerName = new[]
        {
            "A.R.Rahman", "Anirudh", "Illayaraja"
        };

        private static readonly string[] ArtistName = new[]
        {
            "Rajini", "Kamal", "Vijay"
        };

        private static readonly string[] AlbumName = new[]
        {
            "Darbar", "Vishwaroopam", "Bigil"
        };


        private static readonly string[] TitleName = new[]
        {
            "Example title", "Vishwaroopam", "Singapenney"
        };

        List<Album> lstAlbum = new List<Album>();

        private readonly ILogger<MusicController> _logger;

     
        public MusicController(ILogger<MusicController> logger)
        {
            _logger = logger;
        }



        [HttpGet]
        [Route("Albums")]
        [Authorize(Roles =Role.User)]
        public IEnumerable<Album> GetAlbums(string composerName=null,string albumName=null, string titleName=null)
        {
            var rng = new Random();
            
            lstAlbum= Enumerable.Range(1, 5).Select(index => new Album
            {              
               
                ReleasedDate = DateTime.Now.AddDays(index),
                AlbumName = AlbumName[rng.Next(AlbumName.Length)],
                ArtistName = ArtistName[rng.Next(ArtistName.Length)],
                ComposerName = ComposerName[rng.Next(ComposerName.Length)],
                TitleName = TitleName[rng.Next(TitleName.Length)]
            })
            .ToList();

           return lstAlbum.Where(x => x.ComposerName == composerName || x.AlbumName== albumName || x.TitleName== titleName).ToList();

        }


        [HttpPost]
        [Authorize(Roles = Role.Admin)]
        public IEnumerable<Album> AddComposingDetails(string composerName = null, string albumName = null, string artistName = null)
        {
            Album album = new Album();
            album.AlbumName = albumName;
            album.ArtistName = artistName;
            album.ComposerName = composerName;
            album.ReleasedDate = DateTime.Now;
            album.TitleName = "";


            lstAlbum.Add(album);

            return lstAlbum;


        }

    }
}
